#define BOARD_NAME "Azteeg X1"
#define SANGUINOLOLU_V_1_2
#include "pins_SANGUINOLOLU_11.h"
