#define BOARD_NAME "Melzi ATmega1284"
#ifdef __AVR_ATmega1284P__
  #define LARGE_FLASH true
#endif
#define SANGUINOLOLU_V_1_2
#include "pins_SANGUINOLOLU_11.h"
