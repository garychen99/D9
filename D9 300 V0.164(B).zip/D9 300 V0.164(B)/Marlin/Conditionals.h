#error "Old configurations? Please delete all #include lines from Configuration.h and Configuration_adv.h."
