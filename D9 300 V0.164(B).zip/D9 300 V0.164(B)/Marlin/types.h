#ifndef __TYPES_H__
#define __TYPES_H__
typedef unsigned long millis_t;
#endif
