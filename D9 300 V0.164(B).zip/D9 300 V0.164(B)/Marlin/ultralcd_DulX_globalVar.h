#ifndef Ultralcd_DulX_globalVar_H
#define Ultralcd_DulX_globalVar_H
#include "Marlin.h"
#endif
